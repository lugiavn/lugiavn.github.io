
gogo = 1;

try
    my_errors;
catch
    my_errors = [];
    kalman_errors = [];
    prior_errors = [];
end


my_errors(end+1,:) = 0;
kalman_errors(end+1,:) = 0;
prior_errors(end+1,:) = 0;

for i=1:length(prediction_times)

    try
    tt = round(timestep + prediction_times(i) * data.time_scale);
    
    my = mean(phyprops{tt});
    
    ka = obv_phyprops(tt).mean';
    ka = (ka - [data.map_min_max(1) data.map_min_max(2)]) / 5;
    
    pr = data.pos_mean;
    pr = (pr - [data.map_min_max(1) data.map_min_max(2)]) / 5;
    
    
    gt = test.positions(round(tt / data.time_scale),1:2);
    gt = (gt - [data.map_min_max(1) data.map_min_max(2)]) / 5;
    
    my_errors(end,i) = norm(my - gt);
    
    kalman_errors(end,i) = norm(ka - gt);
    
    prior_errors(end,i) = norm(pr - gt);
    end
end









