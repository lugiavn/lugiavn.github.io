
for d=1:14
    
    ddata = [];
    
    for e=data.examples(data.training_ids)
    
        detection = triu(ones(data.T));

        for t=1:round(e.length * data.time_scale)-1
            detection = tum_update_detection_scores(detection, ...
                {e.positions(round(t/data.time_scale),:), data.training.phyprops(d,:), ...
                data.training.frameid2timingindex(t, :), data.progress_level_num});
        end
        
        detection = detection(1:t,1:t);
        
        % add to ddata
        ddata = [ddata; detection(detection > 0)];
        
        % viz
        imagesc(detection); colorbar;
        hold on;
        plot(e.action_labels(d).end * data.time_scale, e.action_labels(d).start * data.time_scale, 'ow');
        hold off;
%         pause;
    end
    
    data.training.detection_means(d) = mean(ddata) / 2;
end
