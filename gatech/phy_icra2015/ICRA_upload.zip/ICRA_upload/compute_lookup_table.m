

if data.re_use_frameid2timingindex & exist('re_use_frameid2timingindex.mat')
	load re_use_frameid2timingindex
    data.training.frameid2timingindex = re_use_frameid2timingindex;
else

    for t=1:data.T
    for p=1:data.progress_level_num
        data.training.frameid2timingindex{t,p} = [];
    end;
    end

    for t1=1:data.T
    for t2=t1:data.T
    for p=1:data.progress_level_num

        index = t1 + (t2-1) * data.T;

        t = nx_linear_scale_to_range(p, 1, data.progress_level_num, t1, t2);
        t = round(t);

        data.training.frameid2timingindex{t,p}(end+1) = index;

    end
    end
    end
    
    re_use_frameid2timingindex = data.training.frameid2timingindex;
    save('re_use_frameid2timingindex.mat', 're_use_frameid2timingindex');
end

