
for i=1:length(data.examples)
   
    data.examples(i).label = struct;
    e = data.examples(i);
    disp(e.ID);

    j = 0;

    a_start = -1;
    a_end   = -1;
    for t=1:size(e.labels, 1)-1
    
        % check start
%         if a_start < 0 & strcmp(e.labels{t,3}, 'HumanWalkingProcess')
        if a_start < 0
            a_start = t;
        end
        
        % check end
%         if strcmp(e.labels{t,3}, 'StandingStill') & strcmp(e.labels{t+1,3}, 'HumanWalkingProcess')
        if ~strcmp(e.labels{t,3}, e.labels{t+1,3})
            a_end = t;
        end
        
        % label
        if a_start > 0 & a_end > 0
            
            j = j + 1;
            
            e.label.actions(j).start = a_start;
            e.label.actions(j).end   = a_end;
            e.label.actions(j).name  = e.labels{t,3};
      
            % reset
            a_start = -1;
            a_end   = -1;
        end

    end
   
    data.examples(i) = e;
end

%% do label


for i=6:length(data.examples)
    
    disp(data.examples(i).ID);
    
    vid = VideoReader(data.examples(i).video_file);
    
    for j=1:length(data.examples(i).label.actions)
       
        
        for t=data.examples(i).label.actions(j).start:10:data.examples(i).label.actions(j).end
            image(read(vid, t + data.examples(i).startframe));
            text(30, 30, data.examples(i).label.actions(j).name);
            text(60, 60, data.examples(i).labels{t,3});
            pause(0.1);
        end
        
        label = input('Input: ', 's');
        
        data.examples(i).label.actions(j).name = label;
    end
    
end


% (1) is not good
% (?) is not robot
% (6) is not good











