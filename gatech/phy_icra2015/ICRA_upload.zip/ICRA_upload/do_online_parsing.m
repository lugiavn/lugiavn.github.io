
%% set up inference structure
T           = data.T;
time_scale  = data.time_scale;

sin         = sin_load_grammar_n_gen_network([data.path '/grammar.txt'], T);
durations   = sin_compute_durationFactors_dualGaussian(data.grammar, T, data.time_scale);

detections = {};
for d=1:14
    detections{d} = triu(ones(T));
end

factorTables.start_prior = zeros(1, T);
factorTables.end_prior   = ones(1, T);

factorTables.start_prior(1) = 1;

%% setup

init_phyprop_predict

%nxrecord = nx_record_figures_init(10, 'X');

%% iterate

for timestep=1:99999999
    
    % check last-round and the-end
    t = round(timestep / time_scale);
    if t > test.length
        break;
    end
    lastround = round((timestep + 1) / time_scale) > test.length;
    
    % update detection
    if 1
    for d=1:14
        detections{d} = tum_update_detection_scores(detections{d}, ...
            {test.positions(round(timestep/data.time_scale),:), data.training.phyprops(d,:), ...
            data.training.frameid2timingindex(timestep, :), data.progress_level_num, data.training.detection_means(d)});
    end
    end
    
    % perform inference
    if mod(timestep, 1+inference_skip_rate) == 0 | lastround
        
        factorTables.s = sin_combine_durations_n_detections(data.grammar, ...
            durations, detections, data.training.detection_means);
        sin = sin_perform_inference(sin, factorTables);
        sin = sin_infer_timestep_labels(sin, factorTables);
        
        do_phyprop_predict;
        
        % viz
        do_viz
        pause(0.1);
        %nxrecord = nx_record_figures_process(nxrecord);

        
        cal_errors
        
    end
    
end

%nxrecord = nx_record_figures_terminate(nxrecord);

