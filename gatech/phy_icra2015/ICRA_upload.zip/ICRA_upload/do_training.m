


data.grammar = sin_load_grammar('grammar.txt');

viz_detection = 0;

%% train duration
for i=data.training_ids
for a=data.examples(i).action_labels
    if a.start > 0 & a.end > a.start
        symbolid = data.grammar.name2id.(a.name);
        try
            data.training.durations{symbolid}.data(end+1) = a.end - a.start + 1;
        catch
            data.training.durations{symbolid}.data        = a.end - a.start + 1;
        end
    end
end
end

for i=1:length(data.training.durations)
    if ~isempty(data.training.durations{i}) & ~isempty(data.training.durations{i}.data)
        data.training.durations{i}.mean = mean(data.training.durations{i}.data);
        data.training.durations{i}.var  = 3 * var(data.training.durations{i}.data);
    end
end

% update grammar
for i=1:length(data.training.durations)
    if ~isempty(data.training.durations{i}) & ~isempty(data.training.durations{i}.data)

        data.grammar.symbols(i).params.duration_mean = data.training.durations{i}.mean;
        data.grammar.symbols(i).params.duration_var  = max(100, data.training.durations{i}.var);
 
    end
end

%%

detectors_count = 0;

for i=1:length(data.grammar.symbols)
    if data.grammar.symbols(i).is_terminal
        detectors_count = detectors_count + 1;
        data.grammar.symbols(i).params.detector_id = detectors_count;
    end
end


%% train detection

% init
for d=1:detectors_count
for p=1:data.progress_level_num
    data.training.phyprops(d,p).data = [];
end
end

% collect data
for p=1:data.progress_level_num
for e=data.examples(data.training_ids)
for a=e.action_labels
    
    d = data.grammar.symbols(data.grammar.name2id.(a.name)).params.detector_id;

    tt = nx_linear_scale_to_range(p, 1, data.progress_level_num, a.start, a.end);
    tt = round(tt);
    
    data.training.phyprops(d,p).data(end+1,:) = e.positions(tt,:);
end
end
end

% compute mean & var
for d=1:detectors_count
for p=1:data.progress_level_num
    data.training.phyprops(d,p).mean = mean(data.training.phyprops(d,p).data);
    data.training.phyprops(d,p).var  = cov(data.training.phyprops(d,p).data) * 2;
end
end

% viz
if 0
for d=1:detectors_count
    clf 
    hold on;
    for p=1:data.progress_level_num

        plot(data.training.phyprops(d,p).mean(1), data.training.phyprops(d,p).mean(2), '*');
        plotgauss2d(data.training.phyprops(d,p).mean(1:2)', data.training.phyprops(d,p).var(1:2,1:2)/9);
        
        xlim([data.map_min_max(1) data.map_min_max(3)]);
        ylim([data.map_min_max(2) data.map_min_max(4)]);
    end
    hold off;
%     for_journal
    pause
end
end



%% compute detection mean

if data.re_use_detectionmean & exist('re_use_detectionmean.mat')
    load re_use_detectionmean
    data.training.detection_means = detection_means;
else
    compute_detection_means
    detection_means = data.training.detection_means;
    save('re_use_detectionmean.mat', 'detection_means');
end

