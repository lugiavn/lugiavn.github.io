

%% frame

try
    f = read(vid, f);
catch
    vid = VideoReader(test.video_file);
    f = read(vid, t + test.start_frame);
end

subplot(3, 3, [3 6]);
imshow(f);

%% plot predictions
i = 1 + 2 * length(prediction_times);
for tt=round(timestep + prediction_times * data.time_scale)
    subplot(3, length(prediction_times), i); i = i + 1;
    h = particles_2_heatmap(phyprops{tt}, [data.map_min_max(3) - data.map_min_max(1) data.map_min_max(4) - data.map_min_max(2)] / 5);
        
    imagesc(imfilter(h, fspecial('gaussian',[90 90], 10),'same'));
    colormap gray
    
    % plot ground truth position
    try
        hold on;
        x = (test.positions(round(tt / data.time_scale),1) - data.map_min_max(1) ) / 5;
        y = (test.positions(round(tt / data.time_scale),2) - data.map_min_max(2) ) / 5;
        plot(x, y, '*r');
        
        text(-10, -50, ['(+' num2str(round((tt-timestep) / time_scale / 25 * 10) / 10) 's, timestep ' num2str(tt) ')'], 'BackgroundColor',[.5 1 .5]); 
     
        hold off;
    end
end

%% plot timings
subplot(3, 3, [1 2]);

start_names = {'get_tray', 'get_t', 'get_dish', 'get_fork', 'get_knife', 'get_spoon', 'get_cup'};
sin_plot_timing_distributions(sin, start_names, {'S'});

hold on;

plot([timestep timestep], [0 1]);

for i=1:length(start_names)
for a=test.action_labels
if strcmp(a.name, start_names{i})
    plot(a.start * data.time_scale, 0.01, '*');
end
end
end
hold off;

% 
% subplot(3, 3, [4 5 7 8]);
% actionnames = fields(sin.original_grammar.name2id);
% sin_plot_timesteplabel_distributions(sin, actionnames([1 end-13:end]));
% xlim([0 700])
