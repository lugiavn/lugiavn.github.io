

figure(2);

for p=1:data.progress_level_num
    subplot(1, data.progress_level_num, p);

%         plot(data.training.phyprops(d,p).mean(1), data.training.phyprops(d,p).mean(2), '*');
%         plotgauss2d(data.training.phyprops(d,p).mean(1:2)', data.training.phyprops(d,p).var(1:2,1:2)/9);
        
    hold on;
     plotcov2(data.training.phyprops(d,p).mean(1:2)', data.training.phyprops(d,p).var(1:2,1:2)/9, ...
                'Color' , 'green', 'LineWidth', 4);
     hold off;
        xlim([data.map_min_max(1) data.map_min_max(3)]);
        ylim([data.map_min_max(2) data.map_min_max(4)]);
    
end


