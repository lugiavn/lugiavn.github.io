

K          = struct;

K.F        = repmat([1 0 1 0; 0 1 0 1; 0 0 1 0 ; 0 0 0 1], [1 1 T]); % transition matrix
K.H        = repmat([1 0 0 0; 0 1 0 0], [1 1 T]); % observation matrix

K.Q        = repmat(diag([1 1 data.vel_var] * 10), [1 1 T]); % state noise
K.y        = repmat(data.pos_mean', [1 T]); % observation
K.R        = repmat(diag(data.pos_var) * 100, [1 1 T]); % obv noise

K.y_prior = K.y;
K.R_prior = K.R;

% obv
for timestep=1:T
    
    % compute t
    t = round(timestep / time_scale);
    if t > test.length
        break;
    end
    
    % update
    K.y(:,timestep)   = test.positions(t, [1 2]);
    K.R(:,:,timestep) = eye(2) * 10e-10;
end

% Kalman
[K.xsmooth, K.Vsmooth] = kalman_smoother(K.y, K.F, K.H, K.Q, K.R, ...
    [data.pos_mean 0 0]', diag([data.pos_var 10 10]) * 2, 'model', [1:T]);


if 0
    axis equal
    hold on;
    for i=1:T
        plot(K.xsmooth(1,i), K.xsmooth(2,i), '.');
        pause(0.5);
    end
    hold off;
end
