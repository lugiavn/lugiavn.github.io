
data         = struct;
data.path    = '.';

data.fixed_sequence_ids = [];

file = fopen([data.path '/dataset_info.csv']);

for i=1:1000

    line = fgetl(file);
    if line == -1, break; end;
    
    tokens = regexp(line,',','split');
    
    data.examples(i).ID          = tokens{1};
    data.examples(i).subject     = tokens{2};
    data.examples(i).task        = tokens{3};
    data.examples(i).start_frame = str2num(tokens{20});
    data.examples(i).end_frame   = str2num(tokens{21});
    data.examples(i).length      = data.examples(i).end_frame - data.examples(i).start_frame + 1;
    % disp(tokens{1});
    
    data.examples(i).labels_file = [data.path '/episodes/' data.examples(i).ID '/labels.csv'];
    data.examples(i).poses_file  = [data.path '/episodes/' data.examples(i).ID '/poses.csv'];
    data.examples(i).video_file  = [data.path '/episodes/' data.examples(i).ID '/cam0.avi'];
    
    % read cvs labels
    labels = csvimport([data.path '/episodes/' data.examples(i).ID '/labels.csv']);
    labels = labels(2:end,2:end);
    data.examples(i).labels = labels;

    % read cvs pose
    pose      = csvread([data.path '/episodes/' data.examples(i).ID '/poses.csv'], 1, 0);
    positions = [mean(pose(:,3:3:end), 2) mean(pose(:,4:3:end), 2) mean(pose(:,5:3:end), 2)];
    
    data.examples(i).poses     = pose;
    data.examples(i).positions = positions;
    
    % read action labels
    data.examples(i).action_labels = struct([]);
    action_labels_file = fopen([data.path '/episodes/' data.examples(i).ID '/labels.sub']);
    try
    line = fgetl(action_labels_file);
    line = fgetl(action_labels_file);
    while line > 0
        %disp(line);
        x = textscan(line, '{%f}{%f}%s');
        a.start = x{1} - data.examples(i).start_frame + 1;
        a.end   = x{2} - data.examples(i).start_frame + 1;
        a.name  = strrep(x{3}{1}, '-', '_');
        try
            data.examples(i).action_labels(end+1) = a;
        catch
            data.examples(i).action_labels = a;
        end
        line = fgetl(action_labels_file);
    end
    data.fixed_sequence_ids(end+1) = i;
    end
    
    % viz skeleton
    if 0
    for t=10:size(pose,1)
        plot3(0,0,0, 'r*');
        hold on;
        for j=3:3:size(pose, 2)

            plot3(pose(t,j), pose(t,j+1), pose(t,j+2), '*');

        end
        hold off;
        pause(0.1);
    end;
    end
    
    % viz positions
    if 0
        vid = VideoReader(data.examples(i).video_file);
        
        for t=1:10:size(pose,1)-10
            
            subplot(1,2,2);
            imshow(read(vid, t + data.examples(i).start_frame - 1));
            
            subplot(1,2,1);
            plot(positions(t,1), positions(t,2), '*');
            xlim([0 5000]);
            ylim([2000 4000]);
            axis equal
            
            
            text(3000,3000, labels{t,1});
            text(3000,2800, labels{t,2});
            text(3000,2600, labels{t,3});
            for a=data.examples(i).action_labels
                if a.start < t & t < a.end
                    text(3000, 3200, a.name);
                end
            end
            
            pause(0.1);
        end
    end
end

fclose(file);

%% some other params & statistics

x     = [];
y     = [];
vel_x = [];
vel_y = [];

for e=data.examples
    
    vel_x = [vel_x; e.positions(2:end, 1) - e.positions(1:end-1, 1)];
    vel_y = [vel_y; e.positions(2:end, 2) - e.positions(1:end-1, 2)];
    
    x     = [x; e.positions(:,1)];
    y     = [y; e.positions(:,2)];
end

data.acc_var     = [var(vel_x(1:end-1)-vel_x(2:end)) var(vel_y(1:end-1)-vel_y(2:end))];
data.vel_var     = [var(vel_x) var(vel_y)];
data.pos_var     = [var(x) var(y)];
data.pos_mean    = [mean(x) mean(y)];
data.map_min_max = [min(x) min(y) max(x) max(y)];
