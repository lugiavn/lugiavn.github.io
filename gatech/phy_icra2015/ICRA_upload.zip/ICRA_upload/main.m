
addpath(genpath('./sin')) 
addpath(genpath('./toy_assembly_predict_hand')) 


%% load dataset
disp 'Loading dataset'

load_dataset

data.re_use_frameid2timingindex = 1;
data.re_use_detectionmean       = 1;

data.progress_level_num = 10;
data.time_scale         = 1/4;
data.T                  = round(data.time_scale * max([data.examples(data.fixed_sequence_ids).length]) * 1.2);

clearvars -except data;
save d0;

%% set up lookup table
% note: the progress level is the completion stage mentioned in the paper

load d0;

disp 'Set up frameid 2 completion-stage lookup table'

compute_lookup_table

clearvars -except data;
save d1;

%% train
clear; load d1;
disp 'Training, might take 15 minutes'

% choose training & testing sequences
i = nx_load_global('test_id', 3);
i = 1 + mod(i, length(data.fixed_sequence_ids));
data.testing_ids  = data.fixed_sequence_ids(i);
data.training_ids = data.fixed_sequence_ids(1:end);
data.training_ids(i) = [];

% do training
do_training

% save
clearvars -except data;
save d2;

%% test

clear;
load d2;
disp 'Run testing, online parsing'

prediction_times = [0.5 1 2 4 8 16 32] * 25;

test                = data.examples(data.testing_ids(1));
do_segmentation     = 0;
online_parsing      = 1;
do_phyprops         = 1;
inference_skip_rate = 1;

do_online_parsing;










