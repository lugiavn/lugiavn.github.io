function v = nx_load_global( name, default_value )
%NX_LOAD_GLOBAL Summary of this function goes here
%   Detailed explanation goes here

    global nx;
    try
        v = nx.(name);
    catch
        v = default_value;
    end
end

