function nx_save_global( name, value )
%NX_SAVE_GLOBAL Summary of this function goes here
%   Detailed explanation goes here

    global nx;
    nx.(name) = value;

end

