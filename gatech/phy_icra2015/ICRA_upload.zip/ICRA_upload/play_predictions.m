

y = K.y_prior;
R = K.R_prior;
y(:,1:timestep) = K.y(:,1:timestep);
R(:,:,1:timestep) = K.R(:,:,1:timestep);

% Just Kalman
[K.xsmooth, K.Vsmooth] = kalman_smoother(y, K.F, K.H, K.Q, R, ...
    [data.pos_mean 0 0]', diag([data.pos_var 10 10]) * 2, 'model', [1:T]);

for t53=1:T
    obv_phyprops(t53).mean = K.xsmooth(1:2,t53);
    obv_phyprops(t53).var  = K.Vsmooth(1:2,1:2,t53);
end

prior_phyprops = {};
for i=1:length(data.grammar.symbols)
if data.grammar.symbols(i).is_terminal
    d = data.grammar.symbols(i).params.detector_id;
    for j=1:size(data.training.phyprops,2)
        prior_phyprops{i}(j).mean = data.training.phyprops(d,j).mean(1:2);
        prior_phyprops{i}(j).var  = data.training.phyprops(d,j).var(1:2,1:2);
    end
end
end

for i=1:size(data.training.phyprops,1)
end

phyprops = sin_predict_phyprops( sin, factorTables, prior_phyprops, obv_phyprops, 1:2:500);

% map
if 1
    for i=1:length(phyprops)
        if ~isempty(phyprops{i})
        
            phyprops{i}(:,1) = (phyprops{i}(:,1) - data.map_min_max(1)) / 5;
            phyprops{i}(:,2) = (phyprops{i}(:,2) - data.map_min_max(2)) / 5;
            
        end
    end
end

%% viz
if 1
    for tt=1:2:500
        h = particles_2_heatmap(phyprops{tt}, [data.map_min_max(3) - data.map_min_max(1) data.map_min_max(4) - data.map_min_max(2)] / 5);
       
        imagesc(imfilter(h, fspecial('gaussian',[50 50], 8),'same'));

        % plot ground truth position
        try
            hold on;
            x = (test.positions(round(tt / data.time_scale),1) - data.map_min_max(1) ) / 5;
            y = (test.positions(round(tt / data.time_scale),2) - data.map_min_max(2) ) / 5;
            plot(x, y, '*r');
            hold off;
        end
        
        pause(1);
    end
end



