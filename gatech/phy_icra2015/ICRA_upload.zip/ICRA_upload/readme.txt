Messy code for the paper:

Augmenting physical state prediction through structured activity inference
Nam N. Vo and Aaron F. Bobick
ICRA 2015

Run main.m

Full dataset can be downloaded from:
https://ias.in.tum.de/software/kitchen-activity-data