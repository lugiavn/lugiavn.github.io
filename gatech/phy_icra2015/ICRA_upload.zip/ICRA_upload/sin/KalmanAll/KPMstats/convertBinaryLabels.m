% labels01 = (labelsPM+1)/2; % maps -1->0, +1->1
% labelsPM = (2*labels01)-1; % maps 0,1 -> -1,1

