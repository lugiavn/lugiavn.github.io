function model = foo(inputs, outputs, varargin)

model.inputs = inputs;
model.outputs = outputs;

