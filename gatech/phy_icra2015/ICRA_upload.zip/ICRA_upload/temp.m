%% disp results
load results_smooth_15s

hold on;
for i=1:3
    r = zeros(1, size(results{1}{1}, 1));
    
    for j=1:length(results)
        r = r + results{j}{i};
    end
    
    r = 5 * r / length(results);
%     r = r(end:-1:1);
    disp(r);
    plot(r, 'color', nxtocolor(i));
end
