
clear;
load d2;

test        = data.examples(data.testing_ids(1));

time_scale  = data.time_scale;

unobserve_start = nx_linear_scale_to_range(rand, 0, 1, 1, test.length - 15 * 25);
unobserve_end   = unobserve_start + 15 * 25;
unobserve_start = round(unobserve_start * time_scale);
unobserve_end   = round(unobserve_end * time_scale);

if 0
test_points = [25 30 40 50 60 70 75];

test_points = round(test.length * test_points / 100);

prediction_times = -test_points;

else
    
    test_points = unobserve_start + (unobserve_end - unobserve_start) * [0:9] / 9;
    prediction_times = test_points / time_scale - test.length;
end


observed_time_step = ones(1, data.T);

% observed_time_step((test.length * time_scale) * 0.25 : (test.length * time_scale) * 0.75) = 0;

observed_time_step(unobserve_start:unobserve_end) = 0;

%% set up inference structure
T           = data.T;
time_scale  = data.time_scale;

sin         = sin_load_grammar_n_gen_network([data.path '/grammar.txt'], T);
durations   = sin_compute_durationFactors_dualGaussian(data.grammar, T, data.time_scale);

detections = {};
for d=1:14
    detections{d} = triu(ones(T));
end

factorTables.start_prior = zeros(1, T);
factorTables.end_prior   = ones(1, T);

factorTables.start_prior(1) = 1;

%%

init_phyprop_predict

%% 

for timestep=1:99999999
    
    % check last-round and the-end
    t = round(timestep / time_scale);
    if t > test.length
        break;
    end
    lastround = round((timestep + 1) / time_scale) > test.length;
    
    % update detection
    if 1 & observed_time_step(timestep)
    for d=1:14
        detections{d} = tum_update_detection_scores(detections{d}, ...
            {test.positions(round(timestep/data.time_scale),:), data.training.phyprops(d,:), ...
            data.training.frameid2timingindex(timestep, :), data.progress_level_num, data.training.detection_means(d)});
    end
    end
    
    % mark end point
    if lastround
        factorTables.end_prior(:) = 0;
        factorTables.end_prior(timestep) = 1;
    end
    
    % perform inference
    if lastround
        
        factorTables.s = sin_combine_durations_n_detections(data.grammar, ...
            durations, detections, data.training.detection_means);
        sin = sin_perform_inference(sin, factorTables);
        sin = sin_infer_timestep_labels(sin, factorTables);
        
        do_phyprop_predict;
        
        % viz
        do_viz
        pause(1);
        
        cal_errors
        
        if 1
            gogo = 1;
        end
    end
end
























