
close all; clear;

%% load dataset
disp 'Load dataset ...'
load_dataset;
clearvars -except data;

% choose training examples & testing examples
data.testing_ids  = randi([1 length(data.examples)]);
data.testing_ids  = 6; % 20 is wrong
data.training_ids = setdiff(1:length(data.examples), data.testing_ids);

%% train
disp 'Training ...'
do_training;
do_training_hands;
clearvars -except data;

%% testing
disp 'Testing ...'

test                = data.examples(data.testing_ids(1));
do_segmentation     = 1;
online_parsing      = 1;
do_phyprops         = 1;
time_scale          = 1 / 6;
inference_skip_rate = 1;

% set prediction time: -x means timestep x, x means current-time+x(seconds)
prediction_times = [1 2 4 8 16 32];


if online_parsing
    do_online_parsing;
else
    % skip everything & perform the final inference
    inference_skip_rate = inf; 
    do_online_parsing;
end


