function [ output_args ] = runmain( input_args )
%RUNMAIN Summary of this function goes here
%   Detailed explanation goes here
    try
        main;
    end

end

