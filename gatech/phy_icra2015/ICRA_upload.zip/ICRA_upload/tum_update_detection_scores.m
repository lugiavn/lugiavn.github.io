function detection = tum_update_detection_scores(detection, stuffs)

    position = stuffs{1};
    d        = stuffs{2};
    
    frameid2timingindex = stuffs{3};
    progress_level_num  = stuffs{4};
    
    try
        detection_mean = stuffs{5};
    catch
        detection_mean = 1;
    end
    
    for p=1:progress_level_num
        
        % run gaussian pdf
        s = mvnpdf(position, ...
            d(p).mean, d(p).var);

        % update detections
        for i=frameid2timingindex{p}
            detection(i) = detection(i) * s ^ (1/progress_level_num) / (detection_mean ^ (1/progress_level_num));
        end
        
    end    
end