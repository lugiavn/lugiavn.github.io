function sin = sin_infer_join_start_n_end( sin )
%SIN_INFER_JOIN_START_N_END Summary of this function goes here
%   Detailed explanation goes here

    disp('This feature has no been implemented yet');

end

